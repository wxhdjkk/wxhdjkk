
wget -O duokai.sh https://raw.gitmirror.com/tengda89757/Titan-Network/main/duokai.sh && chmod +x duokai.sh && ./duokai.sh

wget -O duokai.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/duokai.sh && chmod +x duokai.sh && ./duokai.sh


centos：wget -O duokaicentos.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/duokaicentos.sh && chmod +x duokaicentos.sh && ./duokaicentos.sh

wget -O duokai64.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/duokai64.sh && chmod +x duokai64.sh && ./duokai64.sh






titan+gaganode+proxy

大哥专用：
wget -O dagezhuanyong.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/dagezhuanyong.sh && chmod +x dagezhuanyong.sh && ./dagezhuanyong.sh

xiaomei 专用：
wget -O xiaomei.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/xiaomei.sh && chmod +x xiaomei.sh && ./xiaomei.sh

小美的美女闺蜜但不知道多美专用：
wget -O guimi.sh https://raw.githubusercontent.com/tengda89757/Titan-Network/main/guimi.sh && chmod +x guimi.sh && ./guimi.sh
